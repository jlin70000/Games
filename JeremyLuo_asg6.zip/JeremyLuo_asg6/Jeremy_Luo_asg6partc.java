/* Name: Jeremy Luo NetdID: jl12498
Course: [CS101]
Description: Hangman game using words from a link with three difficulties. Technical notes in the program.
Date: 11/3
*/

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Jeremy_Luo_asg6partc {
	static String[] words;
    static String[] ceiling = { 
        "   ",
    };
    static String[] skateboarderMedium = {
        "  O",
        " /|\\",
        "  | ",
        " / \\",
        "----- ",
        "O   O"
    };
    static String[] skateboarderEasy = {
        "  O",
        " /|\\",
        "  | ",
        "  | ",
        "  | ",
        " / \\",
        "----- ",
        "O   O"
    };
    static String[] skateboarderHard = {
        "  O",
        " \\|/",
        "----- ",
        "O   O"
    };
    static String[] skateboarder = skateboarderMedium;

    // Method to read words from a file
    public static ArrayList<String> WordsFromURL(String url) {
        ArrayList<String> words = new ArrayList<>();
        try {  // try - catch to see if url exists
            // Create a URL object from the URL string given to us

            URL urlObject = new URL(url);
            // Create a BufferedReader to read from the URL stream.
            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(urlObject.openStream()));
            String inputLine;
            // Read each line from the URL stream and add it to the array list of words.
            while ((inputLine = bufferedreader.readLine()) != null) {
                words.add(inputLine.trim());
            }

            // If there is an error, print the stack trace (getMessage)
        } catch (Exception e) {
            e.getMessage();
        }
        return words;
    }

    // Method to randomly select a word from the list of words
    public static String selectRandomWord(ArrayList<String> words) {
        Random random = new Random();
        return words.get(random.nextInt(words.size()));
    }



    public static void displayCeiling(int numGuesses) {
    	for (int i = 0; i < ceiling.length; i++) {
            System.out.println(ceiling[i]);
        }

        int limbsToDisplay = Math.min(numGuesses, skateboarder.length);
        for (int i = 0; i < limbsToDisplay; i++) {
            System.out.println(skateboarder[i]);
        }
    }
    

    public static String initiateGame() {
        Scanner scanner = new Scanner(System.in);

        ArrayList<String> wordList = WordsFromURL("https://cs.nyu.edu/~odeh/resources/python/animals.txt");
        String word = selectRandomWord(wordList);
         int numGuesses = 0;
         char[] guessedWord = new char[word.length() * 2 - 1];
         System.out.print("WELCOME TO A HANGMAN GAME! Choose difficulty (E for Easy (8 guesses), M for Medium (6 guesses), H for Hard (4 guesses)): ");
         String difficulty = scanner.nextLine();

         System.out.println("Start Guessing! If you cannot guess the word before a skateboarder is drawn, YOU LOSE!");

         if (difficulty.equalsIgnoreCase("E")) {
             int maxGuesses = 8;
             skateboarder = skateboarderEasy; // Assign stick figure for Easy difficulty
             for (int i = 0; i < guessedWord.length; i += 2) { // printing _ for each letter
                 guessedWord[i] = '_';
                 if (i < guessedWord.length - 1) {  // makes sure that there are spaces in between '_' so user can easily know the number of letters
                     guessedWord[i + 1] = ' '; 
                 }
             }
          // Game loop for Easy difficulty
             while (numGuesses < maxGuesses) {  
                 displayCeiling(numGuesses);
                 System.out.println(String.valueOf(guessedWord));

                 System.out.print("Enter a letter: ");
                 char guess = scanner.next().charAt(0);

                 boolean correctGuess = false;
                 for (int i = 0; i < word.length(); i++) { // iterates over word to see if the guess is in that word
                     if (word.charAt(i) == guess) { // If guess matches letter, guessedWord[i * 2] = guess; updates the guessedWord array to reveal the correct guess in the guessed word.
                         guessedWord[i * 2] = guess; 
                         correctGuess = true;
                     }
                 }

                 if (!correctGuess) { // If the user's guess was not correct, the numGuesses counter increments.
                     numGuesses++;
                 }

                 if (String.valueOf(guessedWord).equals(word.replace("", " ").trim())) { // This checks to see if the current state of the guessed word is equal to the actual word
                     displayCeiling(numGuesses);
                     System.out.println("Congratulations! You guessed the word: " + word);
                     return word;
                 }
             }
             // same loop but for the medium difficulty
         } else if (difficulty.equalsIgnoreCase("M")) {
             int maxGuesses = 6;
             skateboarder = skateboarderMedium; 
             for (int i = 0; i < guessedWord.length; i += 2) {
                 guessedWord[i] = '_';
                 if (i < guessedWord.length - 1) {
                     guessedWord[i + 1] = ' '; 
                 }
             }
             
             while (numGuesses < maxGuesses) {  
                 displayCeiling(numGuesses);
                 System.out.println(String.valueOf(guessedWord));

                 System.out.print("Enter a letter: ");
                 char guess = scanner.next().charAt(0);

                 boolean correctGuess = false;
                 for (int i = 0; i < word.length(); i++) {
                     if (word.charAt(i) == guess) {
                         guessedWord[i * 2] = guess; 
                         correctGuess = true;
                     }
                 }

                 if (!correctGuess) {
                     numGuesses++;
                 }

                 if (String.valueOf(guessedWord).equals(word.replace("", " ").trim())) {
                     displayCeiling(numGuesses);
                     System.out.println("Congratulations! You guessed the word: " + word);
                     return word;
                 }
             }
         // same loop but for the hard difficulty

         } else if (difficulty.equalsIgnoreCase("H")) {
             int maxGuesses = 4;
             skateboarder = skateboarderHard; 
             for (int i = 0; i < guessedWord.length; i += 2) {
                 guessedWord[i] = '_';
                 if (i < guessedWord.length - 1) {
                     guessedWord[i + 1] = ' '; 
                 }
             }
             
             while (numGuesses < maxGuesses) {  
                 displayCeiling(numGuesses);
                 System.out.println(String.valueOf(guessedWord));
                 
                 System.out.print("Enter a letter: ");
                 char guess = scanner.next().charAt(0);

                 boolean correctGuess = false;
                 for (int i = 0; i < word.length(); i++) {
                     if (word.charAt(i) == guess) {
                         guessedWord[i * 2] = guess; 
                         correctGuess = true;
                     }
                 }

                 if (!correctGuess) {
                     numGuesses++;
                 }

                 if (String.valueOf(guessedWord).equals(word.replace("", " ").trim())) {
                     displayCeiling(numGuesses);
                     System.out.println("Congratulations! You guessed the word: " + word);
                     System.exit(0);

                     return word;
                 }
             }
         }

         displayCeiling(numGuesses);
         System.out.println("You ran out of guesses. The word was: " + word);
         System.exit(0);

         return word;
        
     }

    public static void main(String[] args) {
    	// call the url method 
        ArrayList<String> wordList = WordsFromURL("https://cs.nyu.edu/~odeh/resources/python/animals.txt");
        words = wordList.toArray(new String[0]); // convert the wordList to an array of strings and assigns it to the variable 'words'.

        String word = initiateGame();
        int numGuesses = 0;
        char[] guessedWord = new char[word.length() * 2 - 1]; 
        for (int i = 0; i < guessedWord.length; i += 2) {
            guessedWord[i] = '_';
            if (i < guessedWord.length - 1) {
                guessedWord[i + 1] = ' '; 
            }
        }

        Scanner scanner = new Scanner(System.in);
        boolean gameIsOver = false;

        while (numGuesses < 6) {
            displayCeiling(numGuesses);
            System.out.println(String.valueOf(guessedWord));

            System.out.print("Enter a letter: ");
            char guess = scanner.next().charAt(0);

            boolean correctGuess = false;
            for (int i = 0; i < word.length(); i++) {
                if (word.charAt(i) == guess) {
                    guessedWord[i * 2] = guess; 
                    correctGuess = true;
                }
            }

            if (!correctGuess) {
                numGuesses++;
            }

            if (String.valueOf(guessedWord).equals(word.replace("", " ").trim())) {
                displayCeiling(numGuesses);
                System.out.println("Congratulations! You guessed the word: " + word);
                gameIsOver = true;
                System.exit(0); // Exit the loop when the game is won
            }
        }

        if (!gameIsOver) {
            displayCeiling(numGuesses);
            System.out.println("You ran out of guesses. The word was: " + word);
        }
    }
}