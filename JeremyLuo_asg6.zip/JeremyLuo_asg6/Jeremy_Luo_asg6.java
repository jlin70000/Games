
/* Name: Jeremy Luo NetdID: jl12498
Course: [CS101]
Description: Hangman game using words from an array with three difficulties. Technical notes in the program.
Date: 11/3
*/


import java.util.Scanner;
import java.util.Random;

public class Jeremy_Luo_asg6 {
    // Array of words for the game

    static String[] words = {"notebook", "university", "sphynx", "jazz", "curacao", "lymph", "espionage", "iatrogenic", "kiwi", "lemon"};

    static String[] ceiling = { // set a ceiling so the skateboarder can print under it
        "   ",
     
    };
    
    // Different skateboarder representations based on difficulty
    static String[] skateboarderMedium = {
        "  O",
        " /|\\",
        "  | ",
        " / \\",
        "----- ",
        "O   O"
    };
    static String[] skateboarderEasy = {
        "  O",
        " /|\\",
        "  | ",
        "  | ",
        "  | ",
        " / \\",
        "----- ",
        "O   O"
    };
    static String[] skateboarderHard = {
        "  O",
        " \\|/",
        "----- ",
        "O   O"
    };
    static String[] skateboarder = skateboarderMedium; // Default stick figure for Medium difficulty

    // Method to randomly select a word from the array called 'words'

    public static String selectRandomWord() {
        Random random = new Random();
        return words[random.nextInt(words.length)];
    }
    // Method to display the ceiling and the skateboarder

    public static void displayCeiling(int numGuesses) {
        for (int i = 0; i < ceiling.length; i++) {
            System.out.println(ceiling[i]);
        }

        int limbsToDisplay = Math.min(numGuesses, skateboarder.length);
        for (int i = 0; i < limbsToDisplay; i++) {
            System.out.println(skateboarder[i]);
        }
    }

    // Method to initiate the game and handle the different difficulties

    public static String initiateGame() {
        Scanner scanner = new Scanner(System.in);

        String word = selectRandomWord();
        int numGuesses = 0;
        char[] guessedWord = new char[word.length() * 2 - 1];
        System.out.print("WELCOME TO A HANGMAN GAME! Choose difficulty (E for Easy (8 guesses), M for Medium (6 guesses), H for Hard (4 guesses)): ");
        String difficulty = scanner.nextLine();

        System.out.println("Start Guessing! If you cannot guess the word before a skateboarder is drawn, YOU LOSE!");

        if (difficulty.equalsIgnoreCase("E")) {
            int maxGuesses = 8;
            skateboarder = skateboarderEasy; // Assign stick figure for Easy difficulty
            for (int i = 0; i < guessedWord.length; i += 2) { // printing _ for each letter
                guessedWord[i] = '_';
                if (i < guessedWord.length - 1) {  // makes sure that there are spaces in between '_' so user can easily know the number of letters
                    guessedWord[i + 1] = ' '; 
                }
            }
         // Game loop for Easy difficulty
            while (numGuesses < maxGuesses) {  
                displayCeiling(numGuesses);
                System.out.println(String.valueOf(guessedWord));

                System.out.print("Enter a letter: ");
                char guess = scanner.next().charAt(0);

                boolean correctGuess = false;
                for (int i = 0; i < word.length(); i++) { // iterates over word to see if the guess is in that word
                    if (word.charAt(i) == guess) { // If guess matches letter, guessedWord[i * 2] = guess; updates the guessedWord array to reveal the correct guess in the guessed word.
                        guessedWord[i * 2] = guess; 
                        correctGuess = true;
                    }
                }

                if (!correctGuess) { // If the user's guess was not correct, the numGuesses counter increments.
                    numGuesses++;
                }

                if (String.valueOf(guessedWord).equals(word.replace("", " ").trim())) { // This checks to see if the current state of the guessed word is equal to the actual word
                    displayCeiling(numGuesses);
                    System.out.println("Congratulations! You guessed the word: " + word);
                    return word;
                }
            }
            // same loop but for the medium difficulty
        } else if (difficulty.equalsIgnoreCase("M")) {
            int maxGuesses = 6;
            skateboarder = skateboarderMedium; 
            for (int i = 0; i < guessedWord.length; i += 2) {
                guessedWord[i] = '_';
                if (i < guessedWord.length - 1) {
                    guessedWord[i + 1] = ' '; 
                }
            }
            
            while (numGuesses < maxGuesses) {  
                displayCeiling(numGuesses);
                System.out.println(String.valueOf(guessedWord));

                System.out.print("Enter a letter: ");
                char guess = scanner.next().charAt(0);

                boolean correctGuess = false;
                for (int i = 0; i < word.length(); i++) {
                    if (word.charAt(i) == guess) {
                        guessedWord[i * 2] = guess; 
                        correctGuess = true;
                    }
                }

                if (!correctGuess) {
                    numGuesses++;
                }

                if (String.valueOf(guessedWord).equals(word.replace("", " ").trim())) {
                    displayCeiling(numGuesses);
                    System.out.println("Congratulations! You guessed the word: " + word);
                    return word;
                }
            }
        // same loop but for the hard difficulty

        } else if (difficulty.equalsIgnoreCase("H")) {
            int maxGuesses = 4;
            skateboarder = skateboarderHard; 
            for (int i = 0; i < guessedWord.length; i += 2) {
                guessedWord[i] = '_';
                if (i < guessedWord.length - 1) {
                    guessedWord[i + 1] = ' '; 
                }
            }
            
            while (numGuesses < maxGuesses) {  
                displayCeiling(numGuesses);
                System.out.println(String.valueOf(guessedWord));
                
                System.out.print("Enter a letter: ");
                char guess = scanner.next().charAt(0);

                boolean correctGuess = false;
                for (int i = 0; i < word.length(); i++) {
                    if (word.charAt(i) == guess) {
                        guessedWord[i * 2] = guess; 
                        correctGuess = true;
                    }
                }

                if (!correctGuess) {
                    numGuesses++;
                }

                if (String.valueOf(guessedWord).equals(word.replace("", " ").trim())) {
                    displayCeiling(numGuesses);
                    System.out.println("Congratulations! You guessed the word: " + word);
                    System.exit(0);

                    return word;
                }
            }
        }

        displayCeiling(numGuesses);
        System.out.println("You ran out of guesses. The word was: " + word);
        System.exit(0);

        return word;
       
    }

    	// main program

        public static void main(String[] args) {
            String word = initiateGame();
            int numGuesses = 0;
            char[] guessedWord = new char[word.length() * 2 - 1]; 
            for (int i = 0; i < guessedWord.length; i += 2) {
                guessedWord[i] = '_';
                if (i < guessedWord.length - 1) {
                    guessedWord[i + 1] = ' '; 
                }
            }

            Scanner scanner = new Scanner(System.in);
            boolean gameIsOver = false; // assign boolean values to end game

            while (numGuesses < 6) {
                displayCeiling(numGuesses);
                System.out.println(String.valueOf(guessedWord));

                System.out.print("Enter a letter: ");
                char guess = scanner.next().charAt(0);

                boolean correctGuess = false;
                for (int i = 0; i < word.length(); i++) {
                    if (word.charAt(i) == guess) {
                        guessedWord[i * 2] = guess; 
                        correctGuess = true; // boolean value to correct guessed word
                    }
                }

                if (!correctGuess) {
                    numGuesses++;
                }

                if (String.valueOf(guessedWord).equals(word.replace("", " ").trim())) {
                    displayCeiling(numGuesses);
                    System.out.println("Congratulations! You guessed the word: " + word);
                    gameIsOver = true;
                    System.exit(0); // Exit the loop when the game is won
                }
            }

            if (!gameIsOver) {
                displayCeiling(numGuesses);
                System.out.println("You ran out of guesses. The word was: " + word);
            }
        }
    }

